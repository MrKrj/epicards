import { describe, expect, it } from 'vitest';
const weights = { Commune: 55, 'Peu commune': 25, Rare: 13, Épique: 5, Légendaire: 1.8, Exclusive: 0.2 };
describe('configuration de drop initiale', () => {
  it('totalise exactement 100 %', () => expect(Object.values(weights).reduce((a,b)=>a+b,0)).toBe(100));
  it('contient six raretés et aucune probabilité négative', () => { expect(Object.keys(weights)).toHaveLength(6); expect(Object.values(weights).every(v=>v>=0)).toBe(true); });
});
